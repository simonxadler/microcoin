<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Cuba admin is super flexible, powerful, clean &amp; modern responsive bootstrap 5 admin template with unlimited possibilities.">
        <meta name="keywords" content="admin template, Cuba admin template, dashboard template, flat admin template, responsive admin template, web app">
        <meta name="author" content="pixelstrap">
        <link rel="icon" href="<?= site_url('/assets/images/favicon.png') ?>" type="image/x-icon">
        <link rel="shortcut icon" href="<?= site_url('/assets/images/favicon.png') ?>" type="image/x-icon">
        <title><?= $setting['site_name'] ?> | Adblocker detected?></title>
        <!-- Google font-->
        <link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&amp;display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&amp;display=swap" rel="stylesheet">
        <!-- Font Awesome-->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
        <style>
            .sidebar-list i{
                min-width: 1.5rem;
            }
            .faucet-icon{
                width: 40px;
            }
            .wrapper{
                position: fixed;
                z-index: 100;
                top: 50%;
                left: 50%;
                width: 100%;
                height: 100vh;
                padding: 40px 30px;
                background: #fff;
                border-radius: 15px;
                box-shadow: 10px 10px 15px rgba(0,0,0,0.06);
                transition: opacity 0.2s 0s ease-in-out,
                            transform 0.2s 0s ease-in-out;
            }
            .wrapper.show{
                opacity: 1;
                pointer-events: auto;
                transform:translate(-50%, -50%) scale(1);
            }
            .wrapper .content,
            .content .warn-icon,
            .warn-icon .icon{
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .wrapper .content{
                flex-direction: column;
            }
            .content .warn-icon{
                height: 115px;
                width: 115px;
                border-radius: 50%;
                background: linear-gradient(#9b27ca 0%, #9927cf 0%, #d33639 100%, #f92121 100%);
            }
            .warn-icon .icon{
                height: 100px;
                width: 100px;
                background: #fff;
                border-radius: inherit;
            }
            .warn-icon .icon i{
                background: linear-gradient(#9b27ca 0%, #9927cf 0%, #d33639 100%, #f92121 100%);
                background-clip: text;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                font-size: 50px;
            }
            .content h2{
                margin-top: 35px;
                font-size: 32px;
            }
            .content p{
                font-size: 19px;
                text-align: center;
                margin-top: 20px;
            }
        </style>
    </head>
    <body>
        <!-- page-wrapper Start-->
        <div class="wrapper show">
            <div class="content">
                <div class="warn-icon">
                    <span class="icon"><i class="fas fa-exclamation"></i></span>
                </div>
                <h2>AdBlock Detected!</h2>
                <p>Our website is made possible by displaying ads to our visitors. Please support us by disabling adblocker on our website.</p>
                <button class="btn btn-danger fs-6" onclick="window.location.href = '<?= site_url('member/dashboard') ?>'">Okay, I've disabled</button>
            </div>
        </div>
    </body>
</html>