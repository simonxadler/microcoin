<?php

namespace Config;

/**
 * Database Script Configuration
 * Centralized database connection settings
 */
class Script
{
    // Database connection settings
    public static $hostname = 'localhost';
    public static $username = '';
    public static $password = '';
    public static $database = '';
    public static $version = '2.0.0'; //don't edit this line unless necessary
    public static $product = '4'; //don't edit this line
}
