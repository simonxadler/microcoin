<?php

namespace App\Controllers\Member;

use App\Controllers\MemberController;
use App\Models\UserModel;

class Referral extends MemberController
{
    public function index()
    {
        $this->data['title'] = 'Referral Program';
        
        // Get referral statistics
        $userModel = new UserModel();
        $referrals = $userModel->where('ref', $this->data['user']['id'])->findAll(10);
        $this->data['totalReferrals'] = count($referrals);
        $this->data['referrals'] = $referrals;
        
        return $this->render_member('member/referral', $this->data);
    }
}